INFO
-------------------------------------------------------------
More detailed information can be found within the doc folder.
  
  
FILES&FOLDERS
-------------------------------------------------------------
mosaic.py     The mosaic application
example.bat   Windows batch file the runs mosaic for an example
              data set
readme.txt    This file              

doc           Documentation
mods          Python modules required by mosaic
data          Example data in FASTA format





  